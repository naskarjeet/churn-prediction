"""
Customer Churn Prediction
--------------------------
Goal: Predict which telecom customers are likely to stop using the service (churn).

Steps covered:
1. Build a realistic telecom customer dataset
2. Exploratory Data Analysis (EDA) to find churn patterns
3. Classification models: Logistic Regression, Random Forest, Gradient Boosting
4. Evaluation: accuracy, recall, ROC-AUC
5. Simple dashboard-style summary chart for business users
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, recall_score, roc_auc_score,
                              roc_curve, confusion_matrix, classification_report)

RANDOM_STATE = 42
np.random.seed(RANDOM_STATE)
OUT = "outputs"

# ---------------------------------------------------------------
# 1. BUILD DATASET (telecom-style, similar to the well-known
#    "Telco Customer Churn" dataset structure)
# ---------------------------------------------------------------
N = 4000

tenure = np.random.exponential(scale=24, size=N).clip(0, 72).round().astype(int)
contract = np.random.choice(["Month-to-month", "One year", "Two year"],
                             size=N, p=[0.55, 0.25, 0.20])
internet = np.random.choice(["DSL", "Fiber optic", "No"], size=N, p=[0.35, 0.45, 0.20])
tech_support = np.random.choice(["Yes", "No"], size=N, p=[0.35, 0.65])
payment = np.random.choice(
    ["Electronic check", "Mailed check", "Bank transfer", "Credit card"],
    size=N, p=[0.35, 0.20, 0.22, 0.23])
senior_citizen = np.random.choice([0, 1], size=N, p=[0.84, 0.16])
partner = np.random.choice(["Yes", "No"], size=N, p=[0.48, 0.52])
paperless_billing = np.random.choice(["Yes", "No"], size=N, p=[0.59, 0.41])

monthly_charges = np.round(
    18 + (internet == "Fiber optic") * np.random.uniform(35, 55, N)
       + (internet == "DSL") * np.random.uniform(15, 30, N)
       + (tech_support == "Yes") * np.random.uniform(5, 12, N)
       + np.random.normal(0, 5, N), 2).clip(18, 120)

total_charges = np.round(monthly_charges * tenure + np.random.normal(0, 50, N), 2).clip(0)

# ---- churn probability driven by realistic risk factors ----
risk = (
    -2.2
    + 1.4 * (contract == "Month-to-month")
    - 0.9 * (contract == "Two year")
    + 0.9 * (internet == "Fiber optic")
    - 0.7 * (tech_support == "Yes")
    - 0.035 * tenure
    + 0.012 * monthly_charges
    + 0.5 * (payment == "Electronic check")
    + 0.3 * senior_citizen
    - 0.25 * (partner == "Yes")
)
churn_prob = 1 / (1 + np.exp(-risk))
churn = (np.random.rand(N) < churn_prob).astype(int)
churn_label = np.where(churn == 1, "Yes", "No")

df = pd.DataFrame({
    "customerID": [f"CUST{i:05d}" for i in range(N)],
    "SeniorCitizen": senior_citizen,
    "Partner": partner,
    "tenure": tenure,
    "Contract": contract,
    "InternetService": internet,
    "TechSupport": tech_support,
    "PaperlessBilling": paperless_billing,
    "PaymentMethod": payment,
    "MonthlyCharges": monthly_charges,
    "TotalCharges": total_charges,
    "Churn": churn_label,
})
df.to_csv(f"{OUT}/telecom_customer_data.csv", index=False)
print(f"Dataset created: {df.shape[0]} rows, {df.shape[1]} columns")
print(f"Overall churn rate: {(df['Churn']=='Yes').mean():.2%}")

# ---------------------------------------------------------------
# 2. EDA — churn patterns
# ---------------------------------------------------------------
fig, axes = plt.subplots(2, 2, figsize=(12, 9))

df.groupby("Contract")["Churn"].apply(lambda s: (s == "Yes").mean()).plot(
    kind="bar", ax=axes[0, 0], color="#4C72B0", title="Churn Rate by Contract Type")
axes[0, 0].set_ylabel("Churn Rate")

df.groupby("InternetService")["Churn"].apply(lambda s: (s == "Yes").mean()).plot(
    kind="bar", ax=axes[0, 1], color="#55A868", title="Churn Rate by Internet Service")
axes[0, 1].set_ylabel("Churn Rate")

axes[1, 0].hist(df[df.Churn == "Yes"]["tenure"], bins=20, alpha=0.6, label="Churned")
axes[1, 0].hist(df[df.Churn == "No"]["tenure"], bins=20, alpha=0.6, label="Stayed")
axes[1, 0].set_title("Tenure Distribution: Churned vs Stayed")
axes[1, 0].set_xlabel("Tenure (months)")
axes[1, 0].legend()

df.groupby("PaymentMethod")["Churn"].apply(lambda s: (s == "Yes").mean()).sort_values().plot(
    kind="barh", ax=axes[1, 1], color="#C44E52", title="Churn Rate by Payment Method")
axes[1, 1].set_xlabel("Churn Rate")

plt.tight_layout()
plt.savefig(f"{OUT}/eda_churn_patterns.png", dpi=130)
plt.close()
print("Saved: eda_churn_patterns.png")

# ---------------------------------------------------------------
# 3. PREPROCESSING
# ---------------------------------------------------------------
model_df = df.drop(columns=["customerID"]).copy()
cat_cols = ["Partner", "Contract", "InternetService", "TechSupport",
            "PaperlessBilling", "PaymentMethod"]
le_store = {}
for c in cat_cols:
    le = LabelEncoder()
    model_df[c] = le.fit_transform(model_df[c])
    le_store[c] = le

model_df["Churn"] = (model_df["Churn"] == "Yes").astype(int)

X = model_df.drop(columns=["Churn"])
y = model_df["Churn"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=RANDOM_STATE, stratify=y)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# ---------------------------------------------------------------
# 4. MODELS
# ---------------------------------------------------------------
models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=8, random_state=RANDOM_STATE),
    "Gradient Boosting": GradientBoostingClassifier(random_state=RANDOM_STATE),
}

results = []
roc_data = {}
best_model_name, best_auc, best_model = None, -1, None

for name, model in models.items():
    if name == "Logistic Regression":
        model.fit(X_train_scaled, y_train)
        probs = model.predict_proba(X_test_scaled)[:, 1]
        preds = model.predict(X_test_scaled)
    else:
        model.fit(X_train, y_train)
        probs = model.predict_proba(X_test)[:, 1]
        preds = model.predict(X_test)

    acc = accuracy_score(y_test, preds)
    rec = recall_score(y_test, preds)
    auc = roc_auc_score(y_test, probs)
    results.append({"Model": name, "Accuracy": round(acc, 3),
                     "Recall": round(rec, 3), "ROC-AUC": round(auc, 3)})
    roc_data[name] = roc_curve(y_test, probs)

    if auc > best_auc:
        best_auc, best_model_name, best_model = auc, name, model

results_df = pd.DataFrame(results)
results_df.to_csv(f"{OUT}/model_comparison.csv", index=False)
print("\nModel comparison:")
print(results_df.to_string(index=False))
print(f"\nBest model: {best_model_name} (ROC-AUC = {best_auc:.3f})")

# ---------------------------------------------------------------
# 5. ROC CURVE PLOT
# ---------------------------------------------------------------
plt.figure(figsize=(7, 6))
for name, (fpr, tpr, _) in roc_data.items():
    auc_val = results_df.loc[results_df.Model == name, "ROC-AUC"].values[0]
    plt.plot(fpr, tpr, label=f"{name} (AUC={auc_val:.2f})")
plt.plot([0, 1], [0, 1], linestyle="--", color="gray")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve Comparison")
plt.legend()
plt.tight_layout()
plt.savefig(f"{OUT}/roc_curve.png", dpi=130)
plt.close()
print("Saved: roc_curve.png")

# ---------------------------------------------------------------
# 6. CONFUSION MATRIX (best model)
# ---------------------------------------------------------------
if best_model_name == "Logistic Regression":
    best_preds = best_model.predict(X_test_scaled)
else:
    best_preds = best_model.predict(X_test)

cm = confusion_matrix(y_test, best_preds)
plt.figure(figsize=(5, 4))
plt.imshow(cm, cmap="Blues")
plt.title(f"Confusion Matrix — {best_model_name}")
plt.colorbar()
plt.xticks([0, 1], ["No Churn", "Churn"])
plt.yticks([0, 1], ["No Churn", "Churn"])
for i in range(2):
    for j in range(2):
        plt.text(j, i, cm[i, j], ha="center", va="center",
                  color="white" if cm[i, j] > cm.max() / 2 else "black")
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.tight_layout()
plt.savefig(f"{OUT}/confusion_matrix.png", dpi=130)
plt.close()
print("Saved: confusion_matrix.png")

# ---------------------------------------------------------------
# 7. FEATURE IMPORTANCE (tree model)
# ---------------------------------------------------------------
tree_model = models["Random Forest"]
importances = pd.Series(tree_model.feature_importances_, index=X.columns).sort_values()
plt.figure(figsize=(7, 6))
importances.plot(kind="barh", color="#4C72B0")
plt.title("Feature Importance — Random Forest")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig(f"{OUT}/feature_importance.png", dpi=130)
plt.close()
print("Saved: feature_importance.png")

# ---------------------------------------------------------------
# 8. SIMPLE HR/BUSINESS-STYLE KPI DASHBOARD SUMMARY
# ---------------------------------------------------------------
with open(f"{OUT}/classification_report.txt", "w") as f:
    f.write(f"Best model: {best_model_name}\n\n")
    f.write(classification_report(y_test, best_preds, target_names=["No Churn", "Churn"]))

print("\nAll outputs saved in the 'outputs' folder.")
