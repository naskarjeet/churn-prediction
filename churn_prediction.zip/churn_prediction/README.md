# Customer Churn Prediction

**Goal:** Predict which telecom customers are likely to stop using the service (churn), so the business can act early to keep them.

## Dataset
A telecom-style customer dataset (`outputs/telecom_customer_data.csv`, 4,000 customers) with fields similar to the well-known Telco Customer Churn dataset: tenure, contract type, internet service, tech support, payment method, monthly/total charges, and churn label.

## Steps Followed
1. **Exploratory Data Analysis (EDA)** — looked at churn rate by contract type, internet service, payment method, and tenure. See `outputs/eda_churn_patterns.png`.
   - Month-to-month contracts churn far more than one/two-year contracts.
   - Fiber optic customers churn more (likely price-sensitive).
   - Customers who leave usually have low tenure.
2. **Classification Models** — trained and compared:
   - Logistic Regression
   - Random Forest
   - Gradient Boosting
3. **Evaluation** — Accuracy, Recall, and ROC-AUC for each model (`outputs/model_comparison.csv`).
   - Best model: **Logistic Regression**, ROC-AUC ≈ 0.79
4. **Explainability** — feature importance chart shows contract type, tenure, and monthly charges are the strongest churn drivers (`outputs/feature_importance.png`).
5. **Diagnostics** — ROC curve (`outputs/roc_curve.png`) and confusion matrix (`outputs/confusion_matrix.png`) for the best model.

## How to Run
```
pip install pandas numpy scikit-learn matplotlib
python churn_analysis.py
```
All charts and result files are saved into the `outputs/` folder.

## Key Result
Customers on **month-to-month contracts**, with **low tenure**, and paying by **electronic check** are the highest churn risk. The business can target this group with retention offers (e.g. discounts for switching to a yearly contract).

## Tech Stack
Python, pandas, NumPy, scikit-learn, Matplotlib
